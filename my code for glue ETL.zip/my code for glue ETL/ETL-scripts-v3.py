import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as func
from awsglue.dynamicframe import DynamicFrame

def main():
    # create glue context
    glueContext = GlueContext(SparkContext.getOrCreate())
    # create a Sparksession
    spark = glueContext.spark_session

    # create orders glue dataframe from catalog
    order_gluedf = glueContext.create_dynamic_frame.from_catalog(database="prod-xuqifan", table_name="orders")
    # create order_product glue dataframe from catalog
    order_products_gluedf = glueContext.create_dynamic_frame.from_catalog(database="prod-xuqifan",
                                                                          table_name="order_products")
    # join orders and order_products table
    order_products_prior_gluedf = Join.apply(order_gluedf.rename_field('order_id', 'order_id1'),
                                             order_products_gluedf, 'order_id1', 'order_id').drop_fields(['order_id1'])

    # convert glue dataframe to spark dataframe
    order_products_prior_df = order_products_prior_gluedf.toDF()
    order_df = order_gluedf.toDF()

    # register temp table for sql query
    temp1_df = order_products_prior_df.registerTempTable("order_products_prior")
    temp2_df = order_df.registerTempTable("orders")

    # create user_features1 table
    user_features_1_df = spark.sql("""SELECT user_id,
     Max(order_number) AS user_orders,
     Sum(days_since_prior_order) AS user_period,
     Avg(days_since_prior_order) AS user_mean_days_since_prior
    FROM orders
    GROUP BY user_id""")

    # create user_features2 table
    user_features_2_df = spark.sql("""SELECT user_id, Count(*) AS user_total_products,
     Count(DISTINCT product_id) AS user_distinct_products ,
     Sum(CASE WHEN reordered = 1 THEN 1 ELSE 0 END) / Cast(Sum(CASE WHEN
    order_number > 1 THEN 1 ELSE 0 END) AS DOUBLE) AS user_reorder_ratio
    FROM order_products_prior
    GROUP BY user_id""")

    # create up_features table
    up_features_df = spark.sql("""SELECT user_id,
     product_id,
     Count(*) AS up_orders,
     Min(order_number) AS up_first_order,
     Max(order_number) AS up_last_order,
     Avg(add_to_cart_order) AS up_average_cart_position
    FROM order_products_prior
    GROUP BY user_id,
     product_id""")

    # create prd_features table
    prd_features_df = spark.sql("""SELECT product_id,
     Count(*) AS prod_orders,
     Sum(reordered) AS prod_reorders,
     Sum(CASE WHEN product_seq_time = 1 THEN 1 ELSE 0 END) AS prod_first_orders,
     Sum(CASE WHEN product_seq_time = 2 THEN 1 ELSE 0 END) AS prod_second_orders
    FROM (SELECT *,
     Rank()
     OVER (
     partition BY user_id, product_id
     ORDER BY order_number) AS product_seq_time
     FROM order_products_prior)
    GROUP BY product_id""")

    # convert spark dataframe to glue dataframe
    user_features_1_gluedf = DynamicFrame.fromDF(user_features_1_df, glueContext, "user_features_1_gluedf")
    user_features_2_gluedf = DynamicFrame.fromDF(user_features_2_df, glueContext, "user_features_2_gluedf")
    up_features_gluedf = DynamicFrame.fromDF(up_features_df, glueContext, "up_features_gluedf")
    prd_features_gluedf = DynamicFrame.fromDF(prd_features_df, glueContext, "prd_features_gluedf")

    # join user features together
    user_features_gluedf = Join.apply(user_features_1_gluedf.rename_field('user_id', 'user_id1'),
                                      user_features_2_gluedf,
                                      'user_id1', 'user_id').drop_fields(['user_id1'])

    # join user features with up features
    user_up_features_gluedf = Join.apply(user_features_gluedf.rename_field('user_id', 'user_id1'), up_features_gluedf,
                                         'user_id1', 'user_id').drop_fields(['user_id1'])

    # join all features together
    all_features_gluedf = Join.apply(user_up_features_gluedf.rename_field('product_id', 'product_id1'),
                                     prd_features_gluedf,
                                     'product_id1', 'product_id').drop_fields(['product_id1'])

    # write results into S3
    all_features_df = all_features_gluedf.toDF()
    all_features_df.repartition(1).write.mode('overwrite').format('csv').save(
        "s3://imba-xuqifan/output", header='true')



if __name__ == '__main__':
    main()